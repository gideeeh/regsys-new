<?php

namespace App\Livewire;

use Livewire\Component;

class ProgramAndCourseManagement extends Component
{
    public function render()
    {
        return view('livewire.program-and-course-management');
    }
}
