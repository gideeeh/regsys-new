<div>
    <h1>Program and Course Management</h1>
    <!-- Your HTML content here -->
</div><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views\livewire\program-and-course-management.blade.php ENDPATH**/ ?>