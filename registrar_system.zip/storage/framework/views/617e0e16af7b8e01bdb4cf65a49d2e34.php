<div x-data="{ searchTerm: '<?php echo e($searchTerm ?? ''); ?>', showModal: false, showMore: false, showNotesModal: false, showNoteForm: false }">
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center h-10">
            <a href="<?php echo e(route('student-records')); ?>" class="font-semibold text-xl text-gray-800 leading-tight no-underline hover:underline">
                <?php echo e(__('Student Records')); ?>

            </a>
            <?php if (isset($component)) { $__componentOriginale48b4598ffc2f41a085f001458a956d1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale48b4598ffc2f41a085f001458a956d1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-form','data' => ['action' => ''.e(route('student-records')).'','placeholder' => 'Search Student']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('search-form'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => ''.e(route('student-records')).'','placeholder' => 'Search Student']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $attributes = $__attributesOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__attributesOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale48b4598ffc2f41a085f001458a956d1)): ?>
<?php $component = $__componentOriginale48b4598ffc2f41a085f001458a956d1; ?>
<?php unset($__componentOriginale48b4598ffc2f41a085f001458a956d1); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>
    
    <div class="py-6 max-h-full">
        <div class="max-w-7xl py-6 mx-auto sm:px-6 lg:px-8" >
            <div class="flex bg-white overflow-hidden shadow-sm sm:rounded-lg p-6">
                <main class="indiv-student-panel">
                    <div class="stu-info flex">
                        <div class="img-frame w-3/12">
                            <img class="w-full" src="<?php echo e(asset('images/profile_pic_sample.jpg')); ?>" alt="<?php echo e($student->last_name); ?>">
                        </div>
                        <div class="stu-details w-9/12">
                            <h1><?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?> <?php echo e($student->suffix); ?></h1>
                            <p>Student Number: <?php echo e($student->student_number); ?></p>
                            <p>Course: <?php echo e($latestEnrollment->latestEnrollment->program->program_code); ?></p>
                            <p>Year Level: <?php echo e($latestEnrollment->latestEnrollment->year_level); ?></p>
                            <p>Scholarship: <?php echo e($latestEnrollment->latestEnrollment->scholarship_type); ?></p>
                            <a href="#" @click="showModal = true">Personal Information</a>
                            <div x-show="showModal" @click.away="showModal = false" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full" id="my-modal">
                                <div class="relative top-20 mx-auto p-5 border w-1/2 shadow-lg rounded-md bg-white">
                                    <div class="mt-3 text-left modal-content"> 
                                        <h2 class="text-xl leading-6 px-7 font-medium text-gray-900">
                                            <?php echo e($student->first_name); ?> <?php echo e($student->middle_name); ?> <?php echo e($student->last_name); ?>

                                        </h2>
                                        <div class="mt-2 px-7 py-3">
                                            <h3 class="text-lg">Contact Information</h3>
                                            <p>School Email: <?php echo e($student->school_email); ?></p>
                                            <p>Personal Email: <?php echo e($student->personal_email); ?></p>
                                            <p>Phone Number: <?php echo e($student->phone_number); ?></p>
                                            <h3>Personal Information</h3>
                                            <p>Address: <?php echo e($student->house_num); ?> <?php echo e($student->street); ?>, <?php echo e($student->brgy); ?>, <?php echo e($student->city_municipality); ?>, <?php echo e($student->province); ?> <?php echo e($student->zipcode); ?></p>
                                            <p>Birthday: <?php echo e($student->birthdate); ?></p>
                                            <h3>Emergency Contacts</h3>
                                            <p>Guardian Name: <?php echo e($student->guardian_name); ?></p>
                                            <p>Guardian Contact: <?php echo e($student->guardian_contact); ?></p>
                                            <!-- Click to Show More -->
                                            <button 
                                                @click="showMore = !showMore" 
                                                class="mt-4 px-4 py-2 bg-blue-500 text-white text-sm font-medium rounded hover:bg-blue-700 focus:outline-none focus:bg-blue-700"
                                                x-text="showMore ? 'Show Less' : 'Show More'"
                                            >
                                            </button>

                                            <!-- Extra Information (conditionally rendered) -->
                                            <div x-show="showMore" x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0" x-transition:enter-end="opacity-100" x-transition:leave="transition ease-in duration-300" x-transition:leave-start="opacity-100" x-transition:leave-end="opacity-0" style="display: none;">
                                                <h3 class="text-lg">Additional Information</h3>
                                                <p>Marital Status: <?php echo e($student->civil_status); ?></p>
                                                <p>Nationality: <?php echo e($student->nationality); ?></p>
                                                <p>Sex: <?php echo e($student->sex); ?></p>
                                                <p>Religion: <?php echo e($student->religion); ?></p>
                                                <p>Elementary: <?php echo e($student->elementary); ?></p>
                                                <p>Elem Year Grad: <?php echo e($student->elem_yr_grad); ?></p>
                                                <p>High School: <?php echo e($student->highschool); ?></p>
                                                <p>HS Year Grad: <?php echo e($student->hs_yr_grad); ?></p>
                                                <p>College: <?php echo e($student->college); ?></p>
                                                <p>College Year Final Year: <?php echo e($student->collge_year_ended); ?></p>
                                                <!-- Add other additional fields here -->
                                            </div>

                                            <!-- Add more personal information fields here -->
                                        </div>
                                        <div class="items-center px-4 py-3">
                                            <button @click="showModal = false" id="ok-btn" class="px-4 py-2 bg-gray-800 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-300">
                                                Close
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                     <div class="stu-academic-info mt-4">
                        <h3 class="text-lg mb-2">Academic History</h3>
                        <?php $__currentLoopData = $enrollmentDetails->groupBy('year_level'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearLevel => $yearDetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <h1><?php echo e(ordinal($yearLevel)); ?> Year</h1>
                            <?php $__currentLoopData = $yearDetails->groupBy('term'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term => $details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <h2>Term: <?php echo e(ordinal($term)); ?></h2>
                            <table class="min-w-full border-collapse border border-gray-300">
                                <thead>
                                    <tr>
                                        <th class="border border-gray-300 px-4 py-2">Subject Code</th>
                                        <th class="border border-gray-300 px-4 py-2">Subject Name</th>
                                        <th class="border border-gray-300 px-4 py-2">Prerequisite 1</th>
                                        <th class="border border-gray-300 px-4 py-2">Prerequisite 2</th>
                                        <th class="border border-gray-300 px-4 py-2">Units (Lec)</th>
                                        <th class="border border-gray-300 px-4 py-2">Units (Lab)</th>
                                        <th class="border border-gray-300 px-4 py-2">Total Units</th>
                                        <th class="border border-gray-300 px-4 py-2">Final Grade</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->subject_code); ?></td>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->subject_name); ?></td>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->Prerequisite_Name_1 ?? '-'); ?></td>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->Prerequisite_Name_2 ?? '-'); ?></td>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->units_lec); ?></td>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->units_lab); ?></td>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->TOTAL); ?></td>
                                        <td class="border border-gray-300 px-4 py-2"><?php echo e($detail->final_grade); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </main>
                <aside class="indiv-student-sidepanel">
                    <div class="stu-notes">
                        <h3 @click="showNotesModal = true" class="cursor-pointer">Notes For This Student</h3>
                        <div x-show="showNotesModal" @click.away="showNotesModal = false" class="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full">
                            <div class="relative top-20 mx-auto p-5 border w-1/2 shadow-lg rounded-md bg-white">
                                <div class="modal-content"> 
                                    <h2 class="text-xl leading-6 px-7 font-medium text-gray-900">Notes for <?php echo e($student->first_name); ?></h2>
                                    <div class="mt-2 px-7 py-3">
                                        <!-- Button to toggle note creation form -->
                                        <button @click="showNoteForm = !showNoteForm" class="mb-4 inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
                                            Add Note
                                        </button>

                                        <!-- Form for adding a new note, hidden initially -->
                                        <div x-show="showNoteForm">
                                            <form action="<?php echo e(route('student-notes.store', ['student_id' => $student->student_id])); ?>" method="POST">
                                                <?php echo csrf_field(); ?> <!-- Laravel's CSRF token input -->
                                                <div class="mb-4">
                                                    <label for="note_title" class="block text-sm font-medium text-gray-700">Note Title</label>
                                                    <input type="text" id="note_title" name="note_title" placeholder="Note title" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md" autocomplete="off">
                                                    <label for="note" class="block text-sm font-medium text-gray-700 mt-2">Note Content</label>
                                                    <textarea id="note" name="note" rows="3" class="shadow-sm focus:ring-indigo-500 focus:border-indigo-500 mt-1 block w-full sm:text-sm border border-gray-300 rounded-md" placeholder="Enter note here..."></textarea>
                                                </div>
                                                <div class="px-4 py-3 text-right sm:px-6">
                                                    <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                                                        Save Note
                                                    </button>
                                                </div>
                                            </form>
                                        </div>

                                        <!-- Display existing notes -->
                                        <div class="mt-4">
                                            <h3 class="text-lg font-medium text-gray-900">Existing Notes</h3>
                                            <?php $__empty_1 = true; $__currentLoopData = $latestEnrollment->notes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $note): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <div class="mt-2">
                                                    <p class="text-sm text-gray-600"><strong><?php echo e($note->note_title); ?></strong>: <?php echo e($note->note); ?>

                                                    <span class="text-xs text-gray-500"><?php echo e($note->created_at->format('M. j, Y - g:i A')); ?></span></p>
                                                </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <p>No notes available.</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="items-center px-4 py-3">
                                        <button @click="showNotesModal = false" class="px-4 py-2 bg-gray-800 text-white text-base font-medium rounded-md w-full shadow-sm hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-gray-300">
                                            Close
                                        </button>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h3>Student's Concerns</h3>
                        <h3>Appointment Schedule</h3>
                        <p>First 50 characters. Clickable for show more</p>
                    </div>
                    <div class="stu-functions">
                        <a href="#">View Current COR</a>
                        <a href="#">View Files</a>
                        <a href="#">Released Records</a>
                        <a href="#">Issue Exam Permit</a>
                        <a href="#">Issue COR</a>
                        <a href="#">Issue Gradeslip</a>
                    </div>
                </aside>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
</div>
<?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/indiv-student-record.blade.php ENDPATH**/ ?>