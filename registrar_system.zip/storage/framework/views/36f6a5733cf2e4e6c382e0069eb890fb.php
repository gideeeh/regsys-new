<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Subjects</h1>
    <table border="1">
        <thead>
            <tr>
                <th>Subject Code</th>
                <th>Subject Name</th>
                <th>Units Lec</th>
                <th>Units Lab</th>
                <th>Total Units</th>
                <th>Prerequisite 1</th>
                <th>Prerequisite 2</th>
                <th>Prerequisite 3</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($subject->subject_code); ?></td>
                <td><?php echo e($subject->subject_name); ?></td>
                <td><?php echo e($subject->units_lec); ?></td>
                <td><?php echo e($subject->units_lab); ?></td>
                <td><?php echo e($subject->units_lab + $subject->units_lec); ?></td>
                <td><?php echo e($subject->prerequisite1->subject_code ?? ' - '); ?></td>
                <td><?php echo e($subject->prerequisite2->subject_code ?? ' - '); ?></td>
                <td><?php echo e($subject->prerequisite3->subject_code ?? ' - '); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views\subjects.blade.php ENDPATH**/ ?>