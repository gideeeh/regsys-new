<form id="autoSubmitForm" method="POST" action="<?php echo e(url('admin/enrollments/enroll/enroll_subjects/' . session('enrollment_id'))); ?>">
    <?php echo csrf_field(); ?>
</form>
<script>
    // Automatically submit the form when the document is ready
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('autoSubmitForm').submit();
    });
</script><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/enrolled-subject.blade.php ENDPATH**/ ?>