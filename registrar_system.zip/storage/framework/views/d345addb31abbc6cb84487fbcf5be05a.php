 

<?php $__env->startSection('content'); ?>
    <h1>Program and Course Management</h1>
    <h2>Program List</h2>
    <h2>Course Catalog</h2>
    <h2>Academic Calendar</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views\admin\course-mgmt.blade.php ENDPATH**/ ?>