
<?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr class="border-b hover:bg-gray-100" x-data="{}" @click="window.location.href='<?php echo e(route('student-records.show', $student->student_id)); ?>'" style="cursor: pointer;">
        <td class="px-6 py-4 text-left"><?php echo e($student->student_number); ?></td>
        <td class="px-6 py-4 text-left"><?php echo e($student->first_name); ?></td>
        <td class="px-6 py-4 text-left"><?php echo e($student->last_name.' '.$student->suffix); ?></td>
        <td class="px-6 py-4 text-left"><?php echo e($student->program_code); ?></td>
        <td class="px-6 py-4 text-left"><?php echo e($student->year_level); ?></td>
    </tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views\partials\student_table_rows.blade.php ENDPATH**/ ?>