<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'disabled' => false, 
    'checked' => false, 
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'disabled' => false, 
    'checked' => false, 
]); ?>
<?php foreach (array_filter(([
    'disabled' => false, 
    'checked' => false, 
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<input type="checkbox" <?php echo e($checked ? 'checked' : ''); ?> <?php echo e($disabled ? 'disabled' : ''); ?> <?php echo $attributes->merge(['class' => '...']); ?>>
<?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views\components\checkbox.blade.php ENDPATH**/ ?>