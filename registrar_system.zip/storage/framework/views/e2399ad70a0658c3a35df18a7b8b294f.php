<div>
    <p>Are you sure you want to delete this program?</p>
    <button wire:click="delete">Yes, Delete</button>
    <button wire:click="$emit('close-modal')">Cancel</button>
</div><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views\livewire\delete-program.blade.php ENDPATH**/ ?>