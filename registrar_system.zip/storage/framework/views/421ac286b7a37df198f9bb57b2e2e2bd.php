
<?php $__env->startSection('content'); ?>
<div x-data="{
        manageProgramModal: false,
        currentYear: '',
        currentTerm: '',
        selectedSubjects: [],
        openModalAndFetchSubjects(year, term) {
            this.currentYear = year;
            this.currentTerm = term;
            this.manageProgramModal = true;
            let programId = <?php echo e($program->program_id); ?>;
            let fetchUrl = `/program/${programId}/subjects/${year}/${term}`;

            axios.get(fetchUrl)
                .then(response => {
                    $('#assign_subject').val(response.data).trigger('change');
                })
                .catch(error => console.error('Error fetching subjects:', error));
        }
    }">
    <?php if (isset($component)) { $__componentOriginal19e517b0cf3d26e2d79737f7cc81ff5e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal19e517b0cf3d26e2d79737f7cc81ff5e = $attributes; } ?>
<?php $component = App\View\Components\AlertMessage::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('alert-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AlertMessage::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal19e517b0cf3d26e2d79737f7cc81ff5e)): ?>
<?php $attributes = $__attributesOriginal19e517b0cf3d26e2d79737f7cc81ff5e; ?>
<?php unset($__attributesOriginal19e517b0cf3d26e2d79737f7cc81ff5e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal19e517b0cf3d26e2d79737f7cc81ff5e)): ?>
<?php $component = $__componentOriginal19e517b0cf3d26e2d79737f7cc81ff5e; ?>
<?php unset($__componentOriginal19e517b0cf3d26e2d79737f7cc81ff5e); ?>
<?php endif; ?>
    <h3 class="flex w-full justify-center bg-sky-950 px-4 rounded-md text-white mb-6 border-b-4 border-amber-300">Curriculum Details</h3>
    <h1><?php echo e($program->program_name); ?></h1>
    <span class="py-8"><em><?php echo e(trim($program->program_desc) ? $program->program_desc : 'No Description'); ?></em></span>
    <div class="flex py-4 flex-col">
        <span><strong>Program Coordinator:</strong> <?php echo e(trim($program->program_coordinator) ? $program->program_coordinator : 'Not Set'); ?></span>
        <span><strong>Total Enrolled Students:</strong></span>
        <span><strong>Total Units:</strong> <?php echo e($total_units); ?></span>
    </div>
    <!-- Display subjects Year 1 to 3 -->
    <?php $__currentLoopData = ['1st Year', '2nd Year', '3rd Year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $yearKey => $yearValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="border-double border-4 border-sky-950 px-4 py-4 mb-6 hover:border-solid rounded-lg">
        <h2 class="text-center bg-sky-950 px-4 rounded-md shadow text-white mb-6"><?php echo e($yearValue); ?></h2>
        <?php $__currentLoopData = ['Term 1', 'Term 2', 'Term 3']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $termKey => $termValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="mb-6">
                <div class="flex items-end justify-center mb-2">
                    <h2 class="mr-1 mb-0"><?php echo e($termValue); ?></h2>
                    <span class="underline text-gray-500 text-xs pb-1.5 hover:text-blue-600 cursor-pointer" @click.prevent="openModalAndFetchSubjects(<?php echo e($yearKey + 1); ?>, <?php echo e($termKey + 1); ?>)">Manage</span>
                </div>
                <div class="overflow-x-auto bg-white rounded-lg shadow overflow-y-auto relative">
                    <?php
                        $year = $yearKey + 1;
                        $term = $termKey + 1;
                    ?>
                    <?php if(isset($program_subjects[$year][$term])): ?>
                    <table class="border-solid table-auto w-full whitespace-no-wrap bg-white table-striped relative">
                        <thead>
                            <th class="w-1/12 bg-sky-600 text-white p-2">Code</th>
                            <th class="w-3/12 bg-sky-600 text-white p-2">Name</th>
                            <th class="w-3/12 bg-sky-600 text-white p-2">Pre-req 1</th>
                            <th class="w-3/12 bg-sky-600 text-white p-2">Pre-req 2</th>
                            <th class="w-1/12 bg-sky-600 text-white p-2">Units(Lec)</th>
                            <th class="w-1/12 bg-sky-600 text-white p-2">Units(Lab)</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $program_subjects[$year][$term]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-b hover:bg-gray-100 cursor-pointer">
                                <td class="border-dashed border-t border-gray-200 p-2 py-4"><strong><?php echo e($program_subject->subject->subject_code); ?></strong></td>
                                <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->subject->subject_name); ?></td>
                                <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->prerequisite_1 ?? '-'); ?></td>
                                <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->prerequisite_2 ?? '-'); ?></td>
                                <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->subject->units_lec); ?></td>
                                <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->subject->units_lab); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div class="flex px-8 py-2 bg-gray-300 text-sm">
                        <span class="w-4/12"><strong>Total Units(Lec):</strong> <?php echo e($totalsByYearTerm[$year][$term]['lec'] ?? '0'); ?></span>
                        <span class="w-4/12"><strong>Total Units(Lab):</strong> <?php echo e($totalsByYearTerm[$year][$term]['lab'] ?? '0'); ?></span>
                        <span class="w-4/12"><strong>Total Units:</strong> <?php echo e($totalsByYearTerm[$year][$term]['total'] ?? '0'); ?></span>
                    </div>
                    <?php else: ?>
                    <span class="px-3">No subjects for this program for this year and term.</span>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <!-- Display Year 4 -->
    <div class="border-double border-4 border-sky-950 px-4 py-4 mb-6 hover:border-solid rounded-lg">
        <h2 class="text-center bg-sky-950 px-4 rounded-md shadow text-white mb-6">4th Year</h2>
        <div class="flex items-end justify-center mb-2">
            <h2 class="mr-1 mb-0">Term 1</h2>
            <span class="underline text-gray-500 text-xs pb-0.5 hover:text-blue-600 cursor-pointer" @click.prevent="openModalAndFetchSubjects(4, 1)">Manage</span>
        </div>
        <div class="overflow-x-auto bg-white rounded-lg shadow overflow-y-auto relative">
            <?php
                $year = 4;
                $term = 1;
            ?>
            <?php if(isset($program_subjects[$year][$term])): ?>
            <table class="border-solid table-auto w-full whitespace-no-wrap bg-white table-striped relative">
                <thead>
                    <th class="w-1/12 bg-sky-600 text-white p-2">Code</th>
                    <th class="w-3/12 bg-sky-600 text-white p-2">Name</th>
                    <th class="w-3/12 bg-sky-600 text-white p-2">Pre-req 1</th>
                    <th class="w-3/12 bg-sky-600 text-white p-2">Pre-req 2</th>
                    <th class="w-1/12 bg-sky-600 text-white p-2">Units(Lec)</th>
                    <th class="w-1/12 bg-sky-600 text-white p-2">Units(Lab)</th>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $program_subjects[$year][$term]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program_subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b hover:bg-gray-100 cursor-pointer">
                        <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->subject->subject_code); ?></td>
                        <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->subject->subject_name); ?></td>
                        <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->prerequisite_1); ?></td>
                        <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->prerequisite_2); ?></td>
                        <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->subject->units_lec); ?></td>
                        <td class="border-dashed border-t border-gray-200 p-2 py-4"><?php echo e($program_subject->subject->units_lab); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <div class="flex px-8 py-2 bg-gray-300 text-sm">
                <span class="w-4/12"><strong>Total Units(Lec):</strong> <?php echo e($totalsByYearTerm[$year][$term]['lec'] ?? '0'); ?></span>
                <span class="w-4/12"><strong>Total Units(Lab):</strong> <?php echo e($totalsByYearTerm[$year][$term]['lab'] ?? '0'); ?></span>
                <span class="w-4/12"><strong>Total Units:</strong> <?php echo e($totalsByYearTerm[$year][$term]['total'] ?? '0'); ?></span>
            </div>
            <?php else: ?>
            <span class="px-3">No subjects for this program for this year and term.</span>
            <?php endif; ?>
        </div>
    </div>
    <!-- Manage Program Modal -->
    <div x-cloak x-show="manageProgramModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center px-4 z-50">
        <div class="modal-content bg-white p-8 rounded-lg shadow-lg overflow-auto max-w-md w-full max-h-[80vh]">
            <h3 class="text-lg font-bold mb-4" x-text="'Manage Subjects: Year - ' + currentYear + ' Term - ' + currentTerm"></h3>
            <form action="<?php echo e(route('program-subject.save', ['program_id' => $program_id])); ?>" method="POST" class="space-y-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="program_id" x-model="<?php echo e($program_id); ?>">
                <input type="hidden" name="year" x-model="currentYear">
                <input type="hidden" name="term" x-model="currentTerm">
                <div>
                    <select id="assign_subject" name="subject_ids[]" multiple="multiple" x-model="selectedSubjects" style="width: 100%;" autofocus>
                        <?php $__currentLoopData = $subjects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($subject->subject_id); ?>"><?php echo e($subject->subject_name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="flex justify-center space-x-4 pt-12">
                    <button type="button" @click="manageProgramModal = false" class="w-4/12 bg-gray-500 text-white px-2 py-2 rounded hover:bg-gray-600 transition ease-in-out duration-150">Cancel</button>
                    <button type="submit" class="w-4/12 bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition ease-in-out duration-150">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        // Initialize Select2 first
        $('#assign_subject').select2({
            width: 'resolve',
            placeholder: "Select a subject",
            allowClear: true,
            minimumInputLength: 1,
            ajax: {
                url: '/admin/functions/get-subjects',
                dataType: 'json',
                delay: 250,
                processResults: function (data) {
                    return {
                        results: data.map(function (item) {
                            return {
                                id: item.subject_id,
                                text: item.subject_code + ' - ' + item.subject_name
                            };
                        })
                    };
                },
                cache: true
            }
        });

        // Then set preselected subjects
    let preselectedSubjects = <?php echo json_encode($selectedSubjectsIds ?? [], 15, 512) ?>;
    $('#assign_subject').val(preselectedSubjects).trigger('change');
    });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/program-profile.blade.php ENDPATH**/ ?>