<div>
    <form wire:submit.prevent="update">
        <div>
            <label>Program Code:</label>
            <input type="text" wire:model="program.program_code">
        </div>
        
        <!-- Repeat for other fields -->
        
        <div>
            <label>Department:</label>
            <select wire:model="program.department_id">
                <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept_name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <button type="submit">Update Program</button>
    </form>
</div>
<?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views\livewire\edit-program.blade.php ENDPATH**/ ?>