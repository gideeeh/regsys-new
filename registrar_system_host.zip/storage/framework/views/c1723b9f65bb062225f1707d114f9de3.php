<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" stroke-width="2" stroke="currentColor" fill="none" stroke-linecap="round" stroke-linejoin="round">
  <path d="M18 6l-12 12" />
  <path d="M6 6l12 12" />
</svg><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\storage\framework\views/4c676918e4ac12c6c7ede70228c97618.blade.php ENDPATH**/ ?>