<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="stu-records py-6 max-h-full">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8" >
            <div class="flex overflow-hidden min-h-screen">
            <!-- Sidebar / Navigation -->
                <aside class="w-1/5 min-h-screen sm:rounded-lg bg-white shadow p-4">
                    <!-- Navigation Links -->
                    <nav class="registrar-functions-nav">
                        <ul class="mt-4" x-data="{ open: false }">
                            <li x-data="{ open: <?php echo e(request()->routeIs('enrollment-records') || request()->routeIs('enrollments.enroll') ? 'true' : 'false'); ?> }">
                                <div @click.prevent="open = !open" class="flex items-center cursor-pointer py-4 px-4 hover:bg-gray-200">
                                    <span class="<?php echo e(request()->routeIs('enrollment-records') || request()->routeIs('enrollments.enroll')  ? 'active-sub' : ''); ?>">Enrollment Records</span>
                                </div>
                                <!-- Submenu -->
                                <ul x-show="open" class="submenu">
                                    <li><a href="<?php echo e(route('enrollment-records')); ?>" class="<?php echo e(request()->routeIs('enrollment-records') ? 'active-main' : ''); ?> block py-2 hover:bg-gray-200">Enrollment Records</a></li>
                                    <li><a href="<?php echo e(route('enrollments.enroll')); ?>" class="<?php echo e(request()->routeIs('enrollments.enroll') ? 'active-main' : ''); ?> block py-2 px-6 hover:bg-gray-200">Enroll Student</a></li>
                                </ul>
                                <!-- Section for further updates -->
                            </li>
                        </ul>
                    </nav>
                </aside>

                <!-- Main Content Area -->
                <main class="w-4/5 bg-white shadow overflow-hidden sm:rounded-lg p-6 ml-4">
                    <!-- Main content goes here -->
                    <?php echo $__env->yieldContent('content'); ?>
                </main>
            </div>
        </div>
    </div>
        
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/enrollments.blade.php ENDPATH**/ ?>