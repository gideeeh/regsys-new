

<?php $__env->startSection('content'); ?>
    <div x-data="{ 
        showModal: false, 
        updateModal: false, 
        deleteModal: false, 
        selectedProgram: null, 
        selectedProgramCode: '', 
        selectedProgramName: '', 
        selectedProgramDesc: '', 
        selectedDegreeType: '', 
        selectedDepartment: '', 
        selectedProgramCoordinator: '', 
        selectedTotalUnits: 0 }"
        @keydown.escape.window="showModal = false;updateModal= false;deleteModal= false">
        <h2 class="text-2xl font-semibold mb-4">Program Management</h2>
        <button @click="showModal = true" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition ease-in-out duration-150">+ Add Program</button>
        
        <!-- Add Program Modal -->
        <div x-cloak x-show="showModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center px-4 z-50">
            <div class="modal-content bg-white p-8 rounded-lg shadow-lg overflow-auto max-w-md w-full max-h-[80vh]">
                <h3 class="text-lg font-bold mb-4">Add New Program</h3>
                
                <form action="<?php echo e(route('program-lists-new-program')); ?>" method="POST" class="space-y-4">
                    <?php echo csrf_field(); ?>
                    <div>
                        <label for="program_code" class="block text-sm font-medium text-gray-700">Program Code:</label>
                        <input type="text" id="program_code" name="program_code" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    </div>
                    <div>
                        <label for="program_name" class="block text-sm font-medium text-gray-700">Program Name:</label>
                        <input type="text" id="program_name" name="program_name" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    </div>
                    <div>
                        <label for="program_description" class="block text-sm font-medium text-gray-700">Program Description:</label>
                        <textarea id="program_description" name="program_description" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"></textarea>
                    </div>
                    <div>
                        <label for="degree_type" class="block text-sm font-medium text-gray-700">Degree Type:</label>
                        <select id="degree_type" name="degree_type" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            <option value="Bachelor">Bachelor</option>
                            <option value="Associate">Associate</option>
                            <option value="Graduate">Graduate</option>
                        </select>
                    </div>
                    <div>
                        <label for="department" class="block text-sm font-medium text-gray-700">Department:</label>
                        <select id="department" name="department" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            <option value="">Select Department</option>
                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($department->id); ?>"><?php echo e($department->dept_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <label for="program_coordinator" class="block text-sm font-medium text-gray-700">Program Coordinator:</label>
                        <input type="text" id="program_coordinator" name="program_coordinator" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                    </div>
                    <div class="flex justify-end space-x-4">
                        <button type="button" @click="showModal = false" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition ease-in-out duration-150">Cancel</button>
                        <button type="submit" class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition ease-in-out duration-150">Save Program</button>
                    </div>
                </form>
            </div>
        </div>
        <!-- Table -->
        <div class="py-4">
            <div class="overflow-x-auto bg-white rounded-lg shadow overflow-y-auto relative" style="max-height: 405px;">
                <table class="border-collapse table-auto w-full whitespace-no-wrap bg-white table-striped relative">
                    <thead>
                        <tr class="text-left">
                            <th class="bg-blue-500 text-white p-2">Program Code</th>
                            <th class="bg-blue-500 text-white p-2">Program Name</th>
                            <th class="bg-blue-500 text-white p-2">Degree Type</th>
                            <th class="bg-blue-500 text-white p-2">Department</th>
                            <th class="bg-blue-500 text-white p-2">Coordinator</th>
                            <th class="bg-blue-500 text-white p-2">Total Units</th>
                            <th class="bg-blue-500 text-white p-2">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $programs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $program): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-b hover:bg-gray-100 cursor-pointer" x-data="{}" @click="window.location.href='<?php echo e(route('program-list.show', $program->program_id)); ?>'">
                            <td class="border-dashed border-t border-gray-200 p-2"><?php echo e($program->program_code); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-2"><?php echo e($program->program_name); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-2"><?php echo e($program->degree_type); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-2"><?php echo e($program->department->dept_name ?? '-'); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-2"><?php echo e($program->program_coordinator ?? '-'); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-2"><?php echo e($program->total_units); ?></td>
                            <td class="border-dashed border-t border-gray-200 p-2">
                                <div class="flex justify-end space-x-4">
                                    <button 
                                        @click.stop="updateModal = true; 
                                                selectedProgram = <?php echo e($program->program_id); ?>; 
                                                selectedProgramCode = '<?php echo e($program->program_code); ?>'; 
                                                selectedProgramName = '<?php echo e($program->program_name); ?>'; 
                                                selectedProgramDesc = '<?php echo e($program->program_desc); ?>';
                                                selectedDegreeType = '<?php echo e($program->degree_type); ?>';
                                                selectedDepartment = '<?php echo e($program->department->dept_id); ?>';
                                                selectedProgramCoordinator = '<?php echo e($program->program_coordinator); ?>';
                                                selectedTotalUnits = <?php echo e($program->total_units); ?>;" 
                                        class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition ease-in-out duration-150">Update</button>
                                    <button @click.stop="deleteModal = true; selectedProgram = <?php echo e($program->program_id); ?>" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition ease-in-out duration-150">Delete</button>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <!-- Delete Modal -->
                <div x-cloak x-show="deleteModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center px-4 z-50">
                    <div class="modal-content bg-white p-8 rounded-lg shadow-lg overflow-auto max-w-md w-full">
                        <h3 class="text-lg font-bold mb-4">Confirm Deletion</h3>
                        <p>Are you sure you want to delete this program?</p>
                        <div class="flex justify-end space-x-4 mt-4">
                            <button @click="deleteModal = false" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition ease-in-out duration-150">Cancel</button>
                            <form :action="'/admin/functions/program-course-management/program_list/delete-program/' + selectedProgram" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition ease-in-out duration-150">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- Update Modal -->
                <div x-cloak x-show="updateModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center px-4 z-50">
                    <div class="modal-content bg-white p-8 rounded-lg shadow-lg overflow-auto max-w-md w-full">
                        <h3 class="text-lg font-bold mb-4">Update Program</h3>
                        <form :action="'/admin/functions/program-course-management/program_list/update-program/' + selectedProgram" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PATCH'); ?>
                            <input type="hidden" name="id" x-model="selectedProgram">
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Program Code:</label>
                                <input type="text" name="program_code" x-model="selectedProgramCode" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div>
                                <label class="block text-sm font-medium text-gray-700">Program Name:</label>
                                <input type="text" name="program_name" x-model="selectedProgramName" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                            </div>
                            <div>
                                <label for="program_desc" class="block text-sm font-medium text-gray-700">Program Description:</label>
                                <textarea name="program_desc" x-model="selectedProgramDesc" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm"></textarea>
                            </div>
                            <div>
                                <label for="degree_type" class="block text-sm font-medium text-gray-700">Degree Type:</label>
                                <select name="degree_type" x-model="selectedDegreeType" required class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                                    <option value="Bachelor">Bachelor</option>
                                    <option value="Associate">Associate</option>
                                    <option value="Graduate">Graduate</option>
                                </select>
                            </div>
                            
                            <div>
                                <label for="department" class="block text-sm font-medium text-gray-700">Department:</label>
                                <select x-model="selectedDepartment" name="department" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                                    <option value="">Select Department</option>
                                    <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($department->dept_id); ?>"><?php echo e($department->dept_name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div>
                                <label for="program_coordinator" class="block text-sm font-medium text-gray-700">Program Coordinator:</label>
                                <input type="text" x-model="selectedProgramCoordinator" name="program_coordinator" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm">
                            </div>
                            <div class="mt-4">
                                <button type="button" @click="updateModal = false" class="bg-gray-500 text-white px-4 py-2 rounded hover:bg-gray-600 transition ease-in-out duration-150">Cancel</button>
                                <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition ease-in-out duration-150">Update</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>        
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.functions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\Documents\Gide\Thesis\Project\registrar_system\resources\views/admin/program-list.blade.php ENDPATH**/ ?>