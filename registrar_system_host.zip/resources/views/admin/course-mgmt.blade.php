@extends('admin.functions') {{-- Adjust the name to point to your main layout file --}}

@section('content')
    <h1>Program and Course Management</h1>
    <h2>Program List</h2>
    <h2>Course Catalog</h2>
    <h2>Academic Calendar</h2>
@endsection