<div>
    <h1>Program and Course Management</h1>
    <!-- Your HTML content here -->
</div>